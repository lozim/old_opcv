// test14.cpp : �������̨Ӧ�ó������ڵ㡣
//


#include "stdafx.h"
#include <fstream>
#include <opencv2/opencv.hpp>
#include <iostream>
#include <list>
#include <vector>
#include <math.h>
#include <stdlib.h>
#include <malloc.h>
#include<stdio.h>
#include<conio.h>
#include<memory.h>
#include<string.h>
#include <cstring>
#include<direct.h>

#define Round(x) ((int)(x+0.5))//////ʵ����������


using namespace cv;
using namespace std;

Scalar color = Scalar(0, 0, 255);
Scalar colorr = Scalar(255, 0,0);
vector<Point> allpoint;

	//conv��������С���任
	double *conv(double u[], double v[], double w[], int m, int n)
{
	int i, j;
	int k = m + n - 1;


	for (i = 0; i < k; i++)
	{
		for (j = max(0, i + 1 - n); j <= min(i, m - 1); j++)
		{
			w[i] += u[j] * v[i - j];
		}

	}
	return w;
}

	//С���任
	double ** xibobianhuan(double * JUM, int L)//
{
	int i = 0, j = 0;


	double hh1[4] = { 0.125, 0.375, 0.375, 0.125 }; double hh2[2] = { 0.5, -0.5 };
	double h1h[4] = { 0 }; double h2h[2] = { 0 };

	for (i = 0; i<4; i++)
	{
		h1h[i] = sqrt(2)*hh1[i];
	}

	for (j = 0; j<2; j++)
	{
		h2h[j] = sqrt(2)*hh2[j];
	}

	int p1p = 4, p2p = 2;




	//	double mm[4][1000]={{0},{0}};///////�޸ķ����ڴ淽ʽ��
	//double ** mm;
	//	mm = malloc(double*, 4);

	double ** mm = new double*[4];
	for (i = 0; i < 4; i++) mm[i] = new double[L];

	for (i = 0; i<4; i++)
	{
		//		mm[i] = malloc(double, L);
		for (int j = 0; j<L; j++)
			mm[i][j] = 0;
	}


	//	double vv[4][1000]={{0},{0}};///////////////////////////////////
	//double ** vv;
	//vv = Malloc(double*, 4);


	double ** vv = new double*[4];
	for (i = 0; i < 4; i++) vv[i] = new double[L];
	for (i = 0; i<4; i++)
	{
		for (int j = 0; j<L; j++)
			vv[i][j] = 0;
	}



	double a1[10000] = { 0 };
	double *fp1;
	double *fp2;
	fp2 = (double*)malloc(L*sizeof(double));
	fp1 = (double*)malloc(L*sizeof(double));
	double b2[10000] = { 0 };
	double b1[10000] = { 0 };
	fp1 = conv(JUM, h1h, b1, L, p1p);
	fp2 = conv(JUM, h2h, b2, L, p2p);

	int aa1 = 0; aa1 = L + p1p - 1;
	int bb1 = 0; bb1 = aa1 - floor((p1p - 1) / 2);
	int aa2 = 0; aa2 = L + p2p - 1;
	int bb2 = 0; bb2 = aa2 - floor((p2p - 1) / 2);

	float x1 = 0; x1 = (float)(((float)p1p + 1) / 2);
	float x2 = 0; x2 = (float)(((float)p2p + 1) / 2);

	int y1 = Round(x1);
	int y2 = Round(x2);
	for (int jj = (y1 - 1); jj <= (bb1 - 1); jj++)
	{
		a1[jj - (y1 - 1)] = b1[jj];
		vv[0][jj - (y1 - 1)] = a1[jj - (y1 - 1)];
	}
	for (int ii = (y2 - 1); ii <= (bb2 - 1); ii++)
	{

		mm[0][ii - (y2 - 1)] = b2[ii];
	}
	int g1 = L;
	for (int ii = 0; ii<L; ii++)
	{
	}


	double hj[10000];
	double gj[10000];
	int p1p_hj = 0, p2p_gj = 0;
	double *sj; int aa3 = 0; int bb3 = 0; float x3 = 0; int y3 = 0; int f = 0;
	double *wj; int aa4 = 0; int bb4 = 0; float x4 = 0; int y4 = 0;
	for (j = 1; j <= 3; j++)
	{
		p1p_hj = 1 + pow(2, j)*(p1p - 1);
		p2p_gj = 1 + pow(2, j)*(p2p - 1);

		memset(hj, 0, sizeof(hj));
		memset(gj, 0, sizeof(gj));

		for (int n1 = 1; n1 <= p1p; n1++)
		{
			f = 1 + pow(2, j)*(n1 - 1);
			hj[f - 1] = h1h[n1 - 1];
		}
		for (int n2 = 1; n2 <= p2p; n2++)
		{
			f = 1 + pow(2, j)*(n2 - 1);
			gj[f - 1] = h2h[n2 - 1];
		}
		double p1[10000] = { 0 };
		double p2[10000] = { 0 };
		sj = (double *)malloc(L*sizeof(double));
		wj = (double *)malloc(L*sizeof(double));
		sj = conv(a1, hj, p1, L, p1p_hj);
		wj = conv(a1, gj, p2, L, p2p_gj);
		memset(a1, 0, sizeof(a1));
		aa3 = L + p1p_hj - 1; bb3 = aa3 - floor((p1p_hj - 1) / 2);
		aa4 = L + p2p_gj - 1; bb4 = aa4 - floor((p2p_gj - 1) / 2);
		x3 = (float)(((float)p1p_hj + 1) / 2);  //
		x4 = (float)(((float)p2p_gj + 1) / 2);
		y3 = Round(x3);
		y4 = Round(x4);


		for (int k1 = (y3 - 1); k1 <= (bb3 - 1); k1++)
		{
			a1[k1 - (y3 - 1)] = p1[k1];
			vv[j][k1 - (y3 - 1)] = a1[k1 - (y3 - 3)];
		}
		for (int k2 = (y4 - 1); k2 <= (bb4 - 1); k2++)
		{

			mm[j][k2 - (y4 - 1)] = p2[k2];
		}
		int g2 = L;


	}

	return mm;
	free(sj);
	sj = 0;
	free(wj);
	wj = 0;

	free(fp1);
	fp1 = 0;
	free(fp2);
	fp2 = 0;

	free(vv);
	vv = 0;
	free(mm);
	mm = 0;
}

	//���ڶԵ㼯����
	bool PointCmp(const Point &a, const Point &b, const Point &center)
	{
		if (a.x >= 0 && b.x < 0)
			return true;
		if (a.x == 0 && b.x == 0)
			return a.y > b.y;
		//����OA������OB�Ĳ��
		int det = (a.x - center.x) * (b.y - center.y) - (b.x - center.x) * (a.y - center.y);
		if (det < 0)
			return true;
		if (det > 0)
			return false;
		//����OA������OB���ߣ��Ծ����жϴ�С
		int d1 = (a.x - center.x) * (a.x - center.x) + (a.y - center.y) * (a.y - center.y);
		int d2 = (b.x - center.x) * (b.x - center.y) + (b.y - center.y) * (b.y - center.y);
		return d1 > d2;
	}
	//���ڶԵ㼯����
	void ClockwiseSortPoints(std::vector<Point> &vPoints)
	{
		//��������
		cv::Point center;
		double x = 0, y = 0;
		for (int i = 0; i < vPoints.size(); i++)
		{
			x += vPoints[i].x;
			y += vPoints[i].y;
		}
		center.x = (int)x / vPoints.size();
		center.y = (int)y / vPoints.size();

		//ð������
		for (int i = 0; i < vPoints.size() - 1; i++)
		{
			for (int j = 0; j < vPoints.size() - i - 1; j++)
			{
				if (PointCmp(vPoints[j], vPoints[j + 1], center))
				{
					cv::Point tmp = vPoints[j];
					vPoints[j] = vPoints[j + 1];
					vPoints[j + 1] = tmp;
				}
			}
		}
	}

	int _tmain(int argc, _TCHAR* argv[])
	{
		Mat input = imread("f:\\10.jpg");
		Mat clone = input.clone();

		cvtColor(input, input, CV_BGR2GRAY);
		threshold(~input, input, 80, 255, THRESH_BINARY);

		vector<vector<Point>> contours;
		vector<Vec4i> hierachy;
		findContours(input, contours,hierachy, RETR_EXTERNAL,CHAIN_APPROX_NONE);
		
		for (int i = 0; i < contours.size(); i++)
		{
			if (contourArea(contours[i])>20000)
			{
				for (int j = 0; j < contours[i].size(); j++)
					allpoint.push_back(contours[i][j]);
			}

		}

		ClockwiseSortPoints(allpoint);//��allpoint����
		//vector<Point> inverse_allpoint;
		//inverse_allpoint = allpoint;
		//reverse(allpoint.begin(), allpoint.end());//��allpoint������˳ʱ�������

		

		//��һ������

		/*Mat rectanglee = imread("f:\\circle2.png");
		Mat re = rectanglee.clone();
		allpoint.clear();

		cvtColor(rectanglee, rectanglee, CV_BGR2GRAY);
		threshold(~rectanglee, rectanglee, 50, 255, THRESH_BINARY);
		

		vector<vector<Point>> contour_re;
		vector<Vec4i> hierachy_re;
		findContours(rectanglee, contour_re, hierachy_re, RETR_EXTERNAL, CHAIN_APPROX_NONE);
		drawContours(re, contour_re, -1, color, 1, 8);
		

		for (int i = 0; i < contour_re.size(); i++)
		{
			{
				for (int j = 0; j < contour_re[i].size(); j++)
				allpoint.push_back(contour_re[i][j]);
			}
		}

		ClockwiseSortPoints(allpoint);
		reverse(allpoint.begin(), allpoint.end());*/
		//���˽�����һ������

		//��allpointǰ��ֵ
		//int insert = 5;//����insertΪҪ���ĵ������
		//vector<Point> beginning;
		//vector<Point> ending;
		//for (int i = 0; i < insert; i++)
		//{
		//	beginning.push_back(allpoint[i]);
		//	ending.push_back(allpoint[allpoint.size() - 1 - i]);
		//}
		//for (int i = 0; i < insert; i++)
		//{
		//	allpoint.push_back(beginning[i]);
		//	allpoint.insert(allpoint.begin(), ending[i]);
		//}
		//��ɶ�allpointǰ��ֵ

		//���˵õ�˳�����allpoint





		int linenum = allpoint.size();
		int * Line_i = new int[linenum];
		int * Line_j = new int[linenum];

		//��ʼ��x��y����
		for (int i = 0; i < linenum; i++)
		{
			Line_i[i] = allpoint[i].x;
			Line_j[i] = allpoint[i].y;

		}

		//ѭ�����ֵ������Ԫ��
		/*int *new_line_i = new int[linenum];
		int *new_line_j = new int[linenum];
		for (int i = 0; i < linenum-5; i++)
		{
			new_line_i[i] = (static_cast<int>((Line_i[i] + Line_i[i + 1] + Line_i[i + 2] + Line_i[i + 3] + Line_i[i + 4]) / 5));
			new_line_j[i] = (static_cast<int>((Line_j[i] + Line_j[i + 1] + Line_j[i + 2] + Line_j[i + 3] + Line_j[i + 4]) / 5));

		}
		for (int i = 0; i < linenum - 5; i++)
		{
			Line_i[i] = new_line_i[i];
			Line_j[i] = new_line_j[i];
		}*/
		//ѭ�����ֵ������Ԫ��


		//��б��
		int qq = 5;
		int nn = 0;
		double * nnn = (double *)calloc(linenum - qq, sizeof(double));//ƽ��ֵ�˲�����������ǣ����5����
		if (nnn == 0)
		{
			return 1;
		}
		for (int i = 0; i<linenum - qq; i++)
		{
			double xx1, yy1, xx2, yy2, k;
			double pi = 3.14159;
			yy1 = (double)Line_j[i];
			xx1 = (double)Line_i[i];
			yy2 = (double)Line_j[i + qq];
			xx2 = (double)Line_i[i + qq];

			if ((yy2 >= yy1) && (xx2 >= xx1))
				k = 180 * atan((yy2 - yy1) / (xx2 - xx1)) / pi;
			else if ((yy2 >= yy1) && (xx2 <= xx1))
				k = 180 - 180 * atan((yy2 - yy1) / (xx1 - xx2)) / pi;
			else if ((yy1 >= yy2) && (xx2 <= xx1))
				k = 180 + 180 * atan((yy1 - yy2) / (xx1 - xx2)) / pi;
			else if ((yy1 >= yy2) && (xx1 <= xx2))
				k = 360 - 180 * atan((yy1 - yy2) / (xx2 - xx1)) / pi;//
			nnn[nn] = k;
			nn++;
		}
		//��б��


		//������Щ��360����ͻ��ĵ�
		for (int i = 0; i < linenum - qq-1; i++)
		{
			if (abs(nnn[i + 1] - nnn[i]) > 180)
			{
				if (nnn[i + 1] > nnn[i])
					nnn[i] += 360;
				else nnn[i + 1] += 360;
			}
		}
		//������Щ��360����ͻ��ĵ�


		//����
		/*int flag = 0;
		for (int i = 1; i < linenum - qq; i++)
		{
			if ((nnn[i - 1] >= 270) && (nnn[i] < 90))
			{
				nnn[i] = nnn[i] + 360;
				if (flag == 0)
					flag = 1;
			}
			else if (flag == 1)
				nnn[i] += 360;
		}*/
		//����

		//��ӡnnn�����ֵ������ǣ�
		/*for (int i = 0; i <linenum - qq; i++)
		{
			cout << nnn[i] << endl;
		}
		int i;
		cin >> i;*/
		//��ӡnnn�����ֵ������ǣ�

		


		double **nnnn = xibobianhuan(nnn, linenum - qq);
		

			//�������ڴ�ӡallpoint��ÿ��nnnnֵ���������Сֵ�����ҽ����ɵ�nnnn��2����i��������data2����
			/*for (int i = 7; i< linenum - qq-7; i++)
			{
				cout << nnnn[2][i] << endl;
			}
			int i;
			cin >> i;*/
			//���˴�ӡallpoint��ÿ��nnnnֵ���������Сֵ���ҽ����ɵ�nnnn��2����i��������data2����  ����

		//������д��f�̵�datak��data2��
		/*std::ofstream file_outk("f:\\datak.txt");
		std::ofstream file_out2("f:\\data2.txt");
		for (int i = 0; i <linenum - qq; i++)
		{
			file_outk << nnn[i] << endl;
		}
		file_outk.close();
		for (int i = 7; i< linenum - qq - 7; i++)
		{
			file_out2 << nnnn[2][i] << endl;
		}
		
		file_out2.close();*/

		//������д��f�̵�datak��data2��
			

			//����㻭��ͼ����
			for (int i = 0 + qq + 6; i <allpoint.size() - qq - 6; i++)
			{
				if (abs(nnnn[2][i])>25)
					circle(clone, allpoint[i], 5, colorr, 1, 8);

			}

			namedWindow("kkjh", CV_WINDOW_NORMAL);
			imshow("kkjh", clone);
			waitKey(0);

			//���˽�������㻭��ͼ����



			//��˳���ӡallpoint���е�ÿ����
			/*for (int i = 0; i < allpoint.size(); i++)
			{
				circle(clone, allpoint[i], 10, color, 1, 8);
				namedWindow("aanimation", CV_WINDOW_NORMAL);
				imshow("aanimation", clone);
				waitKey(50);
				destroyWindow("aanimation");

			}*/
			//���˰�˳���ӡallpoint���е�ÿ�������

			//��ӡ
			//for (int i = 0; i < allpoint.size(); i++)
			//{
			//	circle(re, allpoint[i], 3, colorr, 0.1, 8);
			//namedWindow("aanimation", CV_WINDOW_NORMAL);
			//imshow("aanimation", re);
			//
			//if (abs(nnnn[2][i])>=0)
			//{
			//	cout << i << " ������Ϊ" << allpoint[i].x << " ������Ϊ" << allpoint[i].y<<" �н�" << nnn[i]<<" �仯��" <<nnnn[2][i]<< endl;
			//	//cout << nnn[i] << endl;
			//	waitKey(0);
			//	destroyWindow("aanimation");
			//}
			//waitKey(50);
			//destroyWindow("aanimation");
			//}
			//��ӡ

			

	}
